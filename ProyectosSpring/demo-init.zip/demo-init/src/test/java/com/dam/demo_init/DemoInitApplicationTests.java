package com.dam.demo_init;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoInitApplicationTests {

	@Test
	void contextLoads() {
	}

}
